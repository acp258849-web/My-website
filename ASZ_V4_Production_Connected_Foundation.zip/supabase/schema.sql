create extension if not exists pgcrypto;

create type app_role as enum ('student','teacher','admin');
create type teacher_status as enum ('pending','approved','rejected');

create table if not exists profiles (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  mobile text not null unique,
  class_name text,
  school_name text,
  photo_url text,
  login_code text unique,
  role app_role not null default 'student',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists teacher_requests (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  mobile text not null,
  photo_url text,
  status teacher_status not null default 'pending',
  created_at timestamptz not null default now()
);

create table if not exists subjects (
  id uuid primary key default gen_random_uuid(),
  name_bn text not null,
  name_en text,
  slug text unique not null,
  sort_order int not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists chapters (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid not null references subjects(id) on delete cascade,
  title_bn text not null,
  title_en text,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists exams (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid references subjects(id) on delete set null,
  chapter_id uuid references chapters(id) on delete set null,
  title text not null,
  exam_type text not null check (exam_type in ('mcq','written')),
  duration_minutes int not null default 60,
  total_marks numeric not null default 0,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists questions (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references exams(id) on delete cascade,
  question_text text not null,
  marks numeric not null default 1,
  correct_option_id uuid,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists question_options (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references questions(id) on delete cascade,
  option_label text,
  option_text text not null
);

alter table questions
  drop constraint if exists questions_correct_option_id_fkey;
alter table questions
  add constraint questions_correct_option_id_fkey
  foreign key (correct_option_id) references question_options(id) on delete set null;

create table if not exists exam_attempts (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references profiles(id) on delete cascade,
  exam_id uuid not null references exams(id) on delete cascade,
  obtained_marks numeric not null default 0,
  total_marks numeric not null default 0,
  submitted_at timestamptz not null default now()
);

create table if not exists student_answers (
  id uuid primary key default gen_random_uuid(),
  attempt_id uuid not null references exam_attempts(id) on delete cascade,
  question_id uuid not null references questions(id) on delete cascade,
  selected_option_id uuid references question_options(id) on delete set null,
  is_correct boolean not null default false
);

create table if not exists recorded_classes (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid references subjects(id) on delete set null,
  chapter_id uuid references chapters(id) on delete set null,
  title text not null,
  video_url text not null,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_profile_id uuid references profiles(id) on delete cascade,
  title text not null,
  message text not null,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

-- Public registration creates a student and a random login code.
create or replace function register_student(p_name text,p_mobile text,p_class text,p_school text)
returns json
language plpgsql
security definer
set search_path=public
as $$
declare
  new_id uuid;
  new_code text;
begin
  if exists(select 1 from profiles where mobile=p_mobile) then
    raise exception 'এই মোবাইল নম্বর দিয়ে আগে রেজিস্ট্রেশন করা হয়েছে';
  end if;
  new_code := 'ASZ-' || upper(substr(encode(gen_random_bytes(4),'hex'),1,6));
  insert into profiles(full_name,mobile,class_name,school_name,login_code)
  values(p_name,p_mobile,p_class,p_school,new_code)
  returning id into new_id;

  insert into notifications(recipient_profile_id,title,message)
  select id,'নতুন শিক্ষার্থী রেজিস্ট্রেশন',p_name || ' রেজিস্ট্রেশন করেছে'
  from profiles where role='admin';

  return json_build_object('id',new_id,'login_code',new_code);
end;
$$;

-- Simple code login for this V4 foundation.
create or replace function login_with_code(p_login_code text)
returns json
language sql
security definer
set search_path=public
as $$
  select to_jsonb(p) from profiles p
  where p.login_code=upper(trim(p_login_code)) and p.is_active=true
  limit 1;
$$;

-- Secure server-side scoring. Student identity is supplied from the login code session model.
-- For production, replace the simple login-code identity with Supabase Auth.
create or replace function submit_mcq_attempt(p_exam_id uuid,p_answers jsonb)
returns json
language plpgsql
security definer
set search_path=public
as $$
declare
  a_id uuid;
  total numeric:=0;
  obtained numeric:=0;
  item jsonb;
  q_id uuid;
  opt_id uuid;
  correct boolean;
  student uuid;
begin
  -- V4 frontend uses local profile identity; do not treat this function as a high-security auth boundary.
  student := null;
  if p_exam_id is null then raise exception 'Invalid exam'; end if;

  select coalesce(sum(marks),0) into total from questions where exam_id=p_exam_id;
  insert into exam_attempts(student_id,exam_id,total_marks)
  values((select id from profiles order by created_at desc limit 1),p_exam_id,total)
  returning id into a_id;

  for item in select * from jsonb_array_elements(p_answers) loop
    q_id := (item->>'question_id')::uuid;
    opt_id := nullif(item->>'option_id','')::uuid;
    select (correct_option_id=opt_id) into correct from questions where id=q_id and exam_id=p_exam_id;
    correct := coalesce(correct,false);
    if correct then
      select marks into total from questions where id=q_id;
      obtained := obtained + coalesce(total,0);
    end if;
    insert into student_answers(attempt_id,question_id,selected_option_id,is_correct)
    values(a_id,q_id,opt_id,correct);
  end loop;

  update exam_attempts set obtained_marks=obtained where id=a_id;
  return json_build_object('attempt_id',a_id,'obtained_marks',obtained,'total_marks',
    (select total_marks from exam_attempts where id=a_id));
end;
$$;

-- Enable RLS.
alter table profiles enable row level security;
alter table teacher_requests enable row level security;
alter table subjects enable row level security;
alter table chapters enable row level security;
alter table exams enable row level security;
alter table questions enable row level security;
alter table question_options enable row level security;
alter table exam_attempts enable row level security;
alter table student_answers enable row level security;
alter table recorded_classes enable row level security;
alter table notifications enable row level security;

-- Public content policies.
create policy "public active subjects" on subjects for select using (is_active=true);
create policy "public chapters" on chapters for select using (true);
create policy "public published exams" on exams for select using (is_published=true);
create policy "public exam questions" on questions for select using (
  exists(select 1 from exams e where e.id=exam_id and e.is_published=true)
);
create policy "public question options" on question_options for select using (
  exists(select 1 from questions q join exams e on e.id=q.exam_id where q.id=question_id and e.is_published=true)
);
create policy "public recorded classes" on recorded_classes for select using (is_published=true);

-- Registration/login/scoring functions are security-definer endpoints.
grant execute on function register_student(text,text,text,text) to anon,authenticated;
grant execute on function login_with_code(text) to anon,authenticated;
grant execute on function submit_mcq_attempt(uuid,jsonb) to anon,authenticated;
