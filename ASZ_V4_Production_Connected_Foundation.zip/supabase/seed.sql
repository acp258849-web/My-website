insert into subjects(name_bn,name_en,slug,sort_order) values
('পদার্থবিজ্ঞান','Physics','physics',1),
('রসায়ন','Chemistry','chemistry',2),
('গণিত','Mathematics','math',3),
('জীববিজ্ঞান','Biology','biology',4),
('উচ্চতর গণিত','Higher Mathematics','higher-math',5),
('বাংলা ১ম','Bangla 1st','bangla-1st',6),
('বাংলা ২য়','Bangla 2nd','bangla-2nd',7),
('ইংরেজি','English','english',8),
('বাংলাদেশ ও বিশ্ব পরিচয়','Bangladesh & Global Studies','bgs',9),
('কৃষি শিক্ষা','Agriculture','agriculture',10),
('বিজ্ঞান','Science','science',11)
on conflict (slug) do nothing;
