import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

const SUPABASE_URL = import.meta.env?.VITE_SUPABASE_URL || '';
const SUPABASE_KEY = import.meta.env?.VITE_SUPABASE_ANON_KEY || '';

let supabase = null;
let profile = null;
let currentExam = null;
let timerId = null;
let secondsLeft = 3600;
let lang = 'bn';

const $ = id => document.getElementById(id);
const show = (id,on=true) => $(id).classList.toggle('hidden',!on);

if (SUPABASE_URL && SUPABASE_KEY) {
  supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
} else {
  show('configWarning', true);
  $('configWarning').innerHTML = '<b>Supabase এখনো সংযুক্ত হয়নি।</b><br>V4 চালাতে .env-এ VITE_SUPABASE_URL এবং VITE_SUPABASE_ANON_KEY বসাও।';
}

$('registerBtn').onclick = registerStudent;
$('loginBtn').onclick = loginStudent;
$('logoutBtn').onclick = logout;
$('langBtn').onclick = () => { lang = lang === 'bn' ? 'en' : 'bn'; $('langBtn').textContent = lang === 'bn' ? 'English' : 'বাংলা'; };

async function registerStudent(){
  if(!supabase) return;
  const name=$('regName').value.trim(), mobile=$('regMobile').value.trim(), cls=$('regClass').value.trim(), school=$('regSchool').value.trim();
  if(!name || !mobile || !cls){ $('regResult').textContent='নাম, মোবাইল ও শ্রেণি পূরণ করো।'; show('regResult'); return; }
  const {data,error}=await supabase.rpc('register_student', {p_name:name,p_mobile:mobile,p_class:cls,p_school:school});
  if(error){ $('regResult').textContent='রেজিস্ট্রেশন ব্যর্থ: '+error.message; show('regResult'); return; }
  $('regResult').innerHTML=`<b>রেজিস্ট্রেশন সফল!</b><br>তোমার Login Code: <strong>${data.login_code}</strong><br>এটি নিরাপদে সংরক্ষণ করো।`;
  show('regResult');
}

async function loginStudent(){
  if(!supabase) return;
  const code=$('loginCode').value.trim();
  if(!code) return;
  const {data,error}=await supabase.rpc('login_with_code', {p_login_code:code});
  if(error || !data?.id){ $('loginMsg').textContent='Login code সঠিক নয়।'; return; }
  profile=data;
  localStorage.setItem('asz_profile',JSON.stringify(profile));
  show('authView',false); show('dashboardView',true); show('logoutBtn',true);
  $('welcome').textContent=`স্বাগতম, ${profile.full_name}`;
  $('roleText').textContent=`Class: ${profile.class_name || '-'} | School: ${profile.school_name || '-'}`;
  $('codeBadge').textContent=profile.login_code;
  if(profile.role==='admin'){ show('adminView',true); await loadAdmin(); }
  await loadDashboard();
}

async function logout(){
  profile=null; localStorage.removeItem('asz_profile');
  show('authView',true); show('dashboardView',false); show('adminView',false); show('logoutBtn',false);
}

async function loadDashboard(){
  const {data:subs}=await supabase.from('subjects').select('id,name_bn,name_en,slug').eq('is_active',true).order('sort_order');
  $('statSubjects').textContent=subs?.length||0;
  $('subjects').innerHTML=(subs||[]).map(s=>`<div class="subject"><h3>${escapeHtml(s.name_bn)}</h3><p class="muted">${escapeHtml(s.name_en||'')}</p><button onclick="openSubject('${s.id}')">দেখুন</button></div>`).join('');
  const {data:attempts}=await supabase.from('exam_attempts').select('id,exam_id,obtained_marks,total_marks,submitted_at,exams(title)').eq('student_id',profile.id).order('submitted_at',{ascending:false}).limit(10);
  $('statResults').textContent=attempts?.length||0;
  $('results').innerHTML=(attempts||[]).map(a=>`<div class="classItem"><b>${escapeHtml(a.exams?.title||'Exam')}</b> — ${a.obtained_marks ?? 0}/${a.total_marks ?? 0}</div>`).join('') || '<p class="muted">এখনো কোনো ফলাফল নেই।</p>';
  const {data:classes}=await supabase.from('recorded_classes').select('id,title,video_url,subject_id').eq('is_published',true).order('created_at',{ascending:false}).limit(12);
  $('classes').innerHTML=(classes||[]).map(c=>`<div class="classItem"><b>${escapeHtml(c.title)}</b><br><a href="${safeUrl(c.video_url)}" target="_blank" rel="noopener">ক্লাস দেখুন</a></div>`).join('') || '<p class="muted">কোনো recorded class নেই।</p>';
  const {data:exams}=await supabase.from('exams').select('id').eq('is_published',true);
  $('statExams').textContent=exams?.length||0;
}

window.openSubject=async function(subjectId){
  const {data:exams}=await supabase.from('exams').select('id,title,duration_minutes,total_marks').eq('subject_id',subjectId).eq('is_published',true).order('created_at',{ascending:false});
  const host=$('subjects');
  const s=document.createElement('div'); s.className='card'; s.innerHTML='<h3>এই বিষয়ের পরীক্ষা</h3>';
  (exams||[]).forEach(e=>{const d=document.createElement('div');d.className='examItem';d.innerHTML=`<b>${escapeHtml(e.title)}</b><p>${e.duration_minutes||60} মিনিট · ${e.total_marks||0} নম্বর</p><button>পরীক্ষা শুরু</button>`;d.querySelector('button').onclick=()=>startExam(e);s.appendChild(d)});
  host.prepend(s);
};

async function startExam(exam){
  const {data:questions,error}=await supabase.from('questions').select('id,question_text,marks,question_options(id,option_text,option_label)').eq('exam_id',exam.id).order('sort_order');
  if(error){alert(error.message);return}
  currentExam={...exam,questions:questions||[]};
  $('examTitle').textContent=exam.title;
  $('questions').innerHTML=currentExam.questions.map((q,i)=>`<div class="question"><b>${i+1}. ${escapeHtml(q.question_text)}</b>${(q.question_options||[]).map(o=>`<label class="option"><input type="radio" name="q${q.id}" value="${o.id}"> ${escapeHtml(o.option_label||'')} ${escapeHtml(o.option_text)}</label>`).join('')}</div>`).join('');
  secondsLeft=(exam.duration_minutes||60)*60; updateTimer(); clearInterval(timerId); timerId=setInterval(()=>{secondsLeft--;updateTimer();if(secondsLeft<=0){clearInterval(timerId);submitExam()}},1000);
  $('examDialog').showModal();
}
function updateTimer(){ $('timer').textContent=`${String(Math.floor(secondsLeft/60)).padStart(2,'0')}:${String(secondsLeft%60).padStart(2,'0')}`; }
$('submitExam').onclick=submitExam;

async function submitExam(){
  if(!currentExam||!profile)return;
  clearInterval(timerId);
  const answers=currentExam.questions.map(q=>({question_id:q.id,option_id:document.querySelector(`input[name="q${q.id}"]:checked`)?.value||null}));
  const {data,error}=await supabase.rpc('submit_mcq_attempt',{p_exam_id:currentExam.id,p_answers:answers});
  $('examDialog').close();
  if(error){alert('Result জমা দিতে সমস্যা: '+error.message);return}
  alert(`পরীক্ষা জমা হয়েছে। প্রাপ্ত নম্বর: ${data.obtained_marks}/${data.total_marks}`);
  await loadDashboard();
}

async function loadAdmin(){
  const [{count:students},{count:teachers},{count:exams}]=await Promise.all([
    supabase.from('profiles').select('*',{count:'exact',head:true}).eq('role','student'),
    supabase.from('teacher_requests').select('*',{count:'exact',head:true}),
    supabase.from('exams').select('*',{count:'exact',head:true})
  ]);
  $('adminStudents').textContent=students||0; $('adminTeachers').textContent=teachers||0; $('adminExams').textContent=exams||0;
}

function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function safeUrl(v){try{const u=new URL(v);return ['https:','http:'].includes(u.protocol)?u.href:'#'}catch{return '#'}}

const saved=localStorage.getItem('asz_profile');
if(saved){try{profile=JSON.parse(saved);show('authView',false);show('dashboardView',true);show('logoutBtn',true);$('welcome').textContent=`স্বাগতম, ${profile.full_name}`;$('roleText').textContent=`Class: ${profile.class_name||'-'} | School: ${profile.school_name||'-'}`;$('codeBadge').textContent=profile.login_code;if(profile.role==='admin'){show('adminView',true);loadAdmin()}loadDashboard()}catch{}}
