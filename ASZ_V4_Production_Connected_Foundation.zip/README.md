# Abdullah Science Zone (ASZ) — V4
Production-connected foundation for Supabase.

## Included
- Student registration with generated login code
- Student login
- Student dashboard
- Subject/chapter browser
- MCQ exam with 1-hour timer
- Result + wrong-answer review
- Teacher application
- Admin dashboard foundation
- Recorded class listing
- Bangla/English UI toggle
- Supabase database schema + RLS

## Setup
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Copy `.env.example` to `.env` and put your Supabase Project URL and anon/public key there.
4. Run a local server (for example `python -m http.server 5173`), then open `http://localhost:5173`.
5. For Vite deployment, use the Vite setup described in `README.md` below.

IMPORTANT:
- Never put a Supabase service-role key in frontend code.
- The included login-code flow is designed as a simple education-platform prototype. For production, consider adding verified phone/email authentication and rate limiting.
- To create the first admin, use Supabase Auth + the SQL instructions in `supabase/admin_setup.sql`.
